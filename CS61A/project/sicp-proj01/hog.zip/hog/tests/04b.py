test = {
  'name': 'Question 4b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> pig_pass(5, 4)
          d763fd836a7bfb096222e985b161b406
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> pig_pass(13, 10)
          d763fd836a7bfb096222e985b161b406
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> pig_pass(7, 10)
          d763fd836a7bfb096222e985b161b406
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> pig_pass(28, 30)
          bc6c4798917b91886d7fa5f56e42878f
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> pig_pass(23, 23)
          d763fd836a7bfb096222e985b161b406
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> pig_pass(22, 23)
          bc6c4798917b91886d7fa5f56e42878f
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> pig_pass(3, 92)
          d763fd836a7bfb096222e985b161b406
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> pig_pass(47, 64)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(28, 29)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(15, 72)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(24, 3)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(46, 55)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(27, 29)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(73, 99)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(27, 28)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(96, 98)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(92, 54)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(11, 12)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(1, 3)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(2, 3)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(48, 74)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(75, 77)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(12, 5)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(18, 20)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(56, 57)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(19, 69)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(9, 11)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(76, 78)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(24, 25)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(97, 98)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(5, 7)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(3, 64)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(62, 90)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(7, 9)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(28, 30)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(92, 94)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(76, 78)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(9, 11)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(87, 16)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(98, 99)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(7, 88)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(43, 44)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(55, 56)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(43, 45)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(15, 16)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(46, 48)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(83, 84)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(91, 7)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(35, 12)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(51, 92)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(64, 49)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(35, 45)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(19, 21)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(20, 21)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(64, 66)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(51, 81)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(45, 40)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(96, 11)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(57, 96)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(97, 99)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(52, 54)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(12, 13)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(51, 52)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(65, 67)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(12, 13)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(94, 96)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(24, 26)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(38, 39)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(79, 81)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(24, 81)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(11, 87)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(38, 54)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(63, 40)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(60, 51)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(82, 83)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(88, 89)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(75, 73)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(86, 24)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(95, 97)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(19, 46)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(18, 46)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(91, 9)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(19, 81)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(56, 58)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(45, 47)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(22, 24)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(43, 44)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(50, 51)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(64, 65)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(74, 75)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(23, 39)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(89, 56)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(32, 13)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(96, 44)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(77, 59)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(32, 79)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(9, 10)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(29, 31)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(46, 82)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(42, 67)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(93, 95)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(61, 62)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(41, 19)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(90, 38)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(35, 51)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(42, 52)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pig_pass(93, 95)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': r"""
      >>> from hog import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
